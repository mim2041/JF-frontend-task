import Home from "@/components/Home/Home";
import React from "react";

const page = () => {
  return (
    <div>
      <Home />
    </div>
  );
};

export default page;
